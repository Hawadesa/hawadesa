package com.example.detan.ui.login;

import junit.framework.TestCase;

public class LoginViewModelFactoryTest extends TestCase {

}