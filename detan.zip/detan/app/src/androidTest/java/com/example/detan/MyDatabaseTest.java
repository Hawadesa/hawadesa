package com.example.detan;

import junit.framework.TestCase;

public class MyDatabaseTest extends TestCase {

}