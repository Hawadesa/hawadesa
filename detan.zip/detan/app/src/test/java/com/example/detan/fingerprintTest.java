package com.example.detan;

import junit.framework.TestCase;

public class fingerprintTest extends TestCase {

}