package com.example.detan;

public class MyDatabaseImpl extends MyDatabase {
}
