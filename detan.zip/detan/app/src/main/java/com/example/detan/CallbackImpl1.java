package com.example.detan;

import javax.security.auth.callback.Callback;

public class CallbackImpl1 extends Callback {
}
