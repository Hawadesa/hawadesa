package com.example.detan;

public class CallbackImpl implements Callback {
}
