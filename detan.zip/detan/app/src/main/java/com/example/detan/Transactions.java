package com.example.detan;

import android.os.Bundle;
import android.widget.Button;

import java.util.Scanner;

public class Transactions {
    int Deposit;
    int Withdraw;
    int Balance = 100000,withdraw,deposit;
    Scanner sc = new Scanner ( System.in );
    int choice = sc.nextInt();
        public <choice> Transactions (int choice){
            case1:
            System.out.println ("Enter money to be withdrawn: ");
            withdraw = sc.nextInt ();
            if (Balance>= Withdraw) {
                Balance =Balance-Withdraw;
                System.out.println ("Success");
            }
            else{
                System.out.println ("Insufficient Balance");
            }
            System.out.println ("");

            case2:
            System.out.print ( "Enter money to be deposited" );
            deposit=sc.nextInt ();
            Balance = (Balance + Deposit);
            System.out.println ("Success");
            System.out.println ("");

            case3:
            System.out.println ("Balance: "+ Balance);
            System.out.println ("");

            case4:
            System.exit ( 0 );



        }
    protected void onCreate(Bundle savedInstanceState) {

    }



    private void setContentView(int activity_transactions2) {
    }
}