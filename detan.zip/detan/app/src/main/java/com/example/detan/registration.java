package com.example.detan;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.text.TextUtils;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class registration extends AppCompatActivity {
    EditText Name;
    EditText Phone;
    EditText IdNumber;
    EditText Email;
    Button Register;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);

        Name = findViewById(R.id.name);
        Phone= findViewById(R.id.phone);
        IdNumber= findViewById(R.id.idnumber);
        Email= findViewById(R.id.email);
        Register= findViewById(R.id.register);
        Register.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View view){
                CheckDataEntered();
            }
        });
    }
    boolean isEmail(EditText text){
        CharSequence email= text.getText().toString();
        return (!TextUtils.isEmpty(email)&& Patterns.EMAIL_ADDRESS.matcher(email).matches());
    }
    boolean isEmpty(EditText text){
        CharSequence str= text.getText().toString();
        return TextUtils.isEmpty(str);
    }



    private void CheckDataEntered() {
        if(isEmpty(Name)){
            Toast t= Toast.makeText(this, "You must enter name to register!", Toast.LENGTH_SHORT);
            t.show();
        }
    }

}