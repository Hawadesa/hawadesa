package com.example.detan.data.model;

/**
 * Data class that captures user information for logged in users retrieved from LoginRepository
 */
public class LoggedInUser {
    private String password;
    private String userId;
    private String displayName;

    public LoggedInUser(String userId, String displayName , String password) {
        this.userId = userId;
        this.displayName = displayName;
        this.password = password;
    }

    public LoggedInUser(String userId, String jane_doe) {

    }

    public String getUserId() {
        return userId;
    }

    public String getDisplayName() {
        return displayName;
    }
}