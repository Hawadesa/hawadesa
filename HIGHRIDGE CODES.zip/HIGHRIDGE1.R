set.seed(123)

tryCatch({
  
  # Create worker data
  workers <- data.frame(
    id = 1:400,
    name = paste0("Worker_", 1:400),
    gender = sample(c("Male", "Female"), 400, replace = TRUE),
    salary = sample(5000:35000, 400, replace = TRUE),
    satisfactorily = FALSE
  )
  
  # Function to determine employee level
  determine_level <- function(salary, gender) {
    employee_level <- "Unassigned"
    
    # Condition 1
    if (salary > 10000 && salary < 20000) {
      employee_level <- "A1"
    }
    
    # Condition 2
    if (salary > 7500 && salary < 30000 && gender == "Female") {
      employee_level <- "A5-F"
    }
    
    return(employee_level)
  }
  
  # Generate payment slips
  for (i in 1:nrow(workers)) {
    
    worker <- workers[i, ]
    
    tryCatch({
      
      salary <- worker$salary
      gender <- worker$gender
      
      employee_level <- determine_level(salary, gender)
      
      # Print payment slip
      cat("------ PAYMENT SLIP ------\n")
      cat(sprintf("Worker ID: %d\n", worker$id))
      cat(sprintf("Name: %s\n", worker$name))
      cat(sprintf("Gender: %s\n", gender))
      cat(sprintf("Salary: $%d\n", salary))
      cat(sprintf("Employee Level: %s\n", employee_level))
      cat("--------------------------\n\n")
      
    }, error = function(e) {
      message(sprintf("Missing data for worker: %s", e$message))
    })
    
  }
  
}, error = function(e) {
  message(sprintf("An error occurred: %s", e$message))
})
